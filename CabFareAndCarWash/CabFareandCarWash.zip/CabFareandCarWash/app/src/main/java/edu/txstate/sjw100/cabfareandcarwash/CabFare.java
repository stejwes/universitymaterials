package edu.txstate.sjw100.cabfareandcarwash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;



public class CabFare extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    double baseFare = 2.00;
    double mileageRate = 3.25;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cab_fare);
        final TextView cabDistance = findViewById(R.id.txtCabDistance);
        final Button calculateFareButton = findViewById(R.id.btnCalculateFare);
        final TextView txtFareResults = findViewById(R.id.txtCabFareOutput);
        final Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(this);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.carTypeArray, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);


        calculateFareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final double dblCabDistance = Double.parseDouble(cabDistance.getText().toString());
                final String selectedCar = (String) spinner.getSelectedItem();

                final double totalFare = dblCabDistance * mileageRate + baseFare;
                final String strTotalFare = String.valueOf((totalFare));


                //"Car Selected:", selectedCar, "Total Fare is:", totalFare
                txtFareResults.setText("Car Selected: " + selectedCar + " and Total Fare is: " + totalFare);

            }
        });


        }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    parent.getItemAtPosition(position);


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }


}
