package edu.txstate.sjw100.cabfareandcarwash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class CarWash extends AppCompatActivity {

    double exteriorWashCost = 8.5;
    double fullPackageCost = 15.5;
    double discountExteriorWash_ten_or_more = 12.5;
    double dblCost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_wash);

        final RadioButton exteriorOnlyWash = findViewById(R.id.radExteriorOnly);
        final RadioButton fullPackage = findViewById(R.id.radFullPkg);
        final TextView numberOfWashes = findViewById(R.id.txtNumberOfWashes);
        final Button calculateButton = findViewById(R.id.btnCalcPkg);
        final TextView washTotal = findViewById(R.id.txtWashTotal);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final double dblNumberOfWashes = Double.parseDouble(numberOfWashes.getText().toString());

                if (exteriorOnlyWash.isChecked()){
                    dblCost = dblNumberOfWashes * fullPackageCost;

                }
                else if (fullPackage.isChecked() && dblNumberOfWashes < 10){
                    dblCost = dblNumberOfWashes * exteriorWashCost;
                }
                else if (dblNumberOfWashes >= 10 && fullPackage.isChecked()){
                    dblCost = dblNumberOfWashes * discountExteriorWash_ten_or_more;
                    CharSequence text = "Discount Applied for more than 10 washes.";
                    Toast.makeText(CarWash.this, text, Toast.LENGTH_LONG).show();
                }
                DecimalFormat formatter = new DecimalFormat("$#.##");
                String strPackageCost = formatter.format(dblCost);
                washTotal.setText("Your total is:" + strPackageCost);





            }
        });


    }
}
