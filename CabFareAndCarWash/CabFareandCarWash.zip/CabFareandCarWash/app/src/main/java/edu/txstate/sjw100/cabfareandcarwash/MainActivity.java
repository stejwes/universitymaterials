package edu.txstate.sjw100.cabfareandcarwash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button cabFareButton = findViewById(R.id.btnCabFare);
        final Button carWashButton = findViewById(R.id.btnCarWash);

        //redirect to cab fare page

        cabFareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CabFare.class);
                startActivity(intent);
            }
        });

        //redirect to carwash page

        carWashButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CarWash.class);
                startActivity(intent);
            }
        });


    }
}
